package com.example.cs360_m3assignment_sabrinashaver;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * RecyclerView Adapter for displaying events
 */
public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    private List<Event> eventList;
    private OnEventDeleteListener deleteListener;

    /**
     * Interface for delete button callbacks
     */
    public interface OnEventDeleteListener {
        void onDeleteClick(int eventId);
    }

    public EventAdapter(List<Event> eventList, OnEventDeleteListener listener) {
        this.eventList = eventList;
        this.deleteListener = listener;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_event, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        Event event = eventList.get(position);

        holder.textEventTitle.setText(event.getTitle());
        holder.textEventTime.setText(event.getTime());

        holder.buttonDelete.setOnClickListener(v ->
                deleteListener.onDeleteClick(event.getId())
        );
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    /**
     * ViewHolder class
     */
    static class EventViewHolder extends RecyclerView.ViewHolder {

        TextView textEventTitle;
        TextView textEventTime;
        ImageButton buttonDelete;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);

            textEventTitle = itemView.findViewById(R.id.textEventTitle);
            textEventTime = itemView.findViewById(R.id.textEventTime);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}