package com.example.cs360_m3assignment_sabrinashaver;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

/**
 * Activity to add a new event to the database
 */
public class AddEventActivity extends AppCompatActivity {

    private EditText editTitle, editLocation, editTime, editDate, editNotes;
    private FloatingActionButton fabSave, fabCancel;
    private DatabaseHelper databaseHelper;

    // TEMP: simulate logged-in user
    private int currentUserId = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        // Link UI elements
        editTitle = findViewById(R.id.editEventTitle);
        editLocation = findViewById(R.id.editEventLocation);
        editTime = findViewById(R.id.editEventTime);
        editDate = findViewById(R.id.editEventDate);
        editNotes = findViewById(R.id.editEventNotes);

        fabSave = findViewById(R.id.fabSave);
        fabCancel = findViewById(R.id.fabCancel);

        databaseHelper = new DatabaseHelper(this);

        // Save button click
        fabSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveEvent();
            }
        });

        // Cancel button click
        fabCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish(); // just close activity
            }
        });
    }

    /**
     * Grab input values and save event to database
     */
    private void saveEvent() {
        String title = editTitle.getText().toString().trim();
        String location = editLocation.getText().toString().trim();
        String time = editTime.getText().toString().trim();
        String date = editDate.getText().toString().trim();
        String notes = editNotes.getText().toString().trim();

        // Basic validation
        if (title.isEmpty() || date.isEmpty() || time.isEmpty()) {
            Toast.makeText(this, "Please fill in Title, Date, and Time.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Add event to database
        boolean success = databaseHelper.addEvent(currentUserId, title, time, date, notes, location);

        if (success) {
            Toast.makeText(this, "Event added successfully!", Toast.LENGTH_SHORT).show();
            finish(); // close activity and return to EventViewActivity
        } else {
            Toast.makeText(this, "Failed to add event. Try again.", Toast.LENGTH_SHORT).show();
        }
    }
}