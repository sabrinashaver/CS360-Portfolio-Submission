package com.example.cs360_m3assignment_sabrinashaver;

/**
 * Event model class representing a single event record
 * from the database.
 */
public class Event {

    private int id;
    private String title;
    private String time;
    private String date;

    public Event(int id, String title, String time, String date) {
        this.id = id;
        this.title = title;
        this.time = time;
        this.date = date;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getTime() {
        return time;
    }

    public String getDate() {
        return date;
    }
}