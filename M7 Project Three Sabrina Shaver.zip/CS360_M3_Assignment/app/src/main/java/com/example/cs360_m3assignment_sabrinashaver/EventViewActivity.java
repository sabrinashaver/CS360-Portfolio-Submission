package com.example.cs360_m3assignment_sabrinashaver;

import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import androidx.core.content.ContextCompat;
import android.widget.Toast;

import android.database.Cursor;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * Displays events for a selected date using RecyclerView
 */
public class EventViewActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EventAdapter adapter;
    private DatabaseHelper databaseHelper;
    private List<Event> eventList;

    // TEMP: simulate logged-in user
    private int currentUserId = 1;

    // TEMP: simulate selected date
    private String selectedDate = "2026-02-23";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_view);

        recyclerView = findViewById(R.id.recyclerViewEvents);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        databaseHelper = new DatabaseHelper(this);
        eventList = new ArrayList<>();

        loadEvents();

        adapter = new EventAdapter(eventList, eventId -> {
            databaseHelper.deleteEvent(eventId);
            loadEvents(); // refresh list after delete
        });

        recyclerView.setAdapter(adapter);
    }

    private void sendSmsIfPermitted(String phoneNumber, String message) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS sent: " + message, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "SMS permission not granted, cannot send message", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Loads events from database into RecyclerView
     */
    private void loadEvents() {
        eventList.clear();

        Cursor cursor = databaseHelper.getEventsForDate(selectedDate, currentUserId);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(
                        cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_ID)
                );
                String title = cursor.getString(
                        cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_TITLE)
                );
                String time = cursor.getString(
                        cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_TIME)
                );
                String date = cursor.getString(
                        cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DATE)
                );

                eventList.add(new Event(id, title, time, date));

            } while (cursor.moveToNext());

            cursor.close();
        }

        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }

        // Send SMS reminders for today's events
        for (Event event : eventList) {
            String message = "Reminder: " + event.getTitle() + " at " + event.getTime();
            sendSmsIfPermitted("1234567890", message); // replace with real user number when available
        }
    }
}