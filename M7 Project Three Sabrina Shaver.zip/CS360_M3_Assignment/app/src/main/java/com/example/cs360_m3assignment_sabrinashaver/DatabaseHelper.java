package com.example.cs360_m3assignment_sabrinashaver;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * DatabaseHelper manages all database creation and version management
 * for user accounts and application data.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "app_database.db";
    private static final int DATABASE_VERSION = 1;

    // Users table
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Events table
    public static final String TABLE_EVENTS = "events";
    public static final String COLUMN_EVENT_ID = "event_id";
    public static final String COLUMN_EVENT_TITLE = "title";
    public static final String COLUMN_EVENT_TIME = "time";
    public static final String COLUMN_EVENT_DATE = "date";
    public static final String COLUMN_EVENT_USER_ID = "user_id";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Create database tables
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        String createUsersTable =
                "CREATE TABLE " + TABLE_USERS + " (" +
                        COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_USERNAME + " TEXT UNIQUE, " +
                        COLUMN_PASSWORD + " TEXT)";

        // Create events table
        String createEventsTable =
                "CREATE TABLE " + TABLE_EVENTS + " (" +
                        COLUMN_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_EVENT_TITLE + " TEXT, " +
                        COLUMN_EVENT_TIME + " TEXT, " +
                        COLUMN_EVENT_DATE + " TEXT, " +
                        "notes TEXT, " +
                        "location TEXT, " +
                        COLUMN_EVENT_USER_ID + " INTEGER)";

        db.execSQL(createUsersTable);
        db.execSQL(createEventsTable);
    }

    /**
     * Handle database upgrades
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    /**
     * Adds a new user to the database
     *
     * @return true if user was added successfully, false if user already exists
     */
    public boolean addUser(String username, String password) {
        if (userExists(username)) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        db.close();

        return result != -1;
    }

    /**
     * Checks if login credentials are valid
     */
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        String selection = COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?";
        String[] selectionArgs = { username, password };

        Cursor cursor = db.query(
                TABLE_USERS,
                null,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        boolean exists = cursor.moveToFirst();
        cursor.close();
        db.close();

        return exists;
    }

    /**
     * Checks if a username already exists
     */
    private boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        String selection = COLUMN_USERNAME + "=?";
        String[] selectionArgs = { username };

        Cursor cursor = db.query(
                TABLE_USERS,
                null,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        boolean exists = cursor.moveToFirst();
        cursor.close();
        db.close();

        return exists;
    }

    // Add new event
    public boolean addEvent(int userId, String title, String time, String date, String notes, String location) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_TITLE, title);
        values.put(COLUMN_EVENT_TIME, time);
        values.put(COLUMN_EVENT_DATE, date);
        values.put("notes", notes);        // new column
        values.put("location", location);  // new column
        values.put(COLUMN_EVENT_USER_ID, userId);

        long result = db.insert(TABLE_EVENTS, null, values);
        db.close();

        return result != -1;
    }

    // Get events for a day
    public Cursor getEventsForDate(String date, int userId) {
        SQLiteDatabase db = this.getReadableDatabase();

        String selection = COLUMN_EVENT_DATE + "=? AND " + COLUMN_EVENT_USER_ID + "=?";
        String[] selectionArgs = { date, String.valueOf(userId) };

        return db.query(
                TABLE_EVENTS,
                null, // all columns
                COLUMN_EVENT_DATE + "=? AND " + COLUMN_EVENT_USER_ID + "=?",
                new String[]{ date, String.valueOf(userId) },
                null,
                null,
                COLUMN_EVENT_TIME + " ASC"
        );
    }

    // Delete events
    public void deleteEvent(int eventId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(
                TABLE_EVENTS,
                COLUMN_EVENT_ID + "=?",
                new String[]{ String.valueOf(eventId) }
        );
        db.close();
    }

    // Update events
    public boolean updateEvent(int eventId, String newTitle, String newTime, String newDate, String newNotes, String newLocation) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_TITLE, newTitle);
        values.put(COLUMN_EVENT_TIME, newTime);
        values.put(COLUMN_EVENT_DATE, newDate);
        values.put("notes", newNotes);
        values.put("location", newLocation);

        int rows = db.update(
                TABLE_EVENTS,
                values,
                COLUMN_EVENT_ID + "=?",
                new String[]{ String.valueOf(eventId) }
        );

        db.close();
        return rows > 0;
    }
}